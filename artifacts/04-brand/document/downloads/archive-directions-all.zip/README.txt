archive-directions-all.zip
Generated 2026-10-15

Contents
  ./ (1 file)
    - archive-directions-all.pdf
  png/ (12 files)
    - direction-a-markers-1024.png
    - direction-a-markers-512.png
    - direction-a-wordmark-1024.png
    - direction-a-wordmark-512.png
    - direction-b-markers-1024.png
    - direction-b-markers-512.png
    - direction-b-wordmark-1024.png
    - direction-b-wordmark-512.png
    - direction-c-markers-1024.png
    - direction-c-markers-512.png
    - direction-c-wordmark-1024.png
    - direction-c-wordmark-512.png
  png-research/ (4 files)
    - ANTI-PATTERN-SCHEMATICS-1024.png
    - ANTI-PATTERN-SCHEMATICS-512.png
    - WORDMARK-DIRECTIONS-1024.png
    - WORDMARK-DIRECTIONS-512.png
  svg/ (6 files)
    - direction-a-markers.svg
    - direction-a-wordmark.svg
    - direction-b-markers.svg
    - direction-b-wordmark.svg
    - direction-c-markers.svg
    - direction-c-wordmark.svg
  svg-research/ (2 files)
    - ANTI-PATTERN-SCHEMATICS.svg
    - WORDMARK-DIRECTIONS.svg

Palette
  #0D0E11  #BE8B32  #EFEBE2

SVG is the master. PNG is rasterised at the standard sizes.
