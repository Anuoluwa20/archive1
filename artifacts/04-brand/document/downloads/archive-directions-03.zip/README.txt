archive-directions-03.zip
Generated 2026-10-15

Contents
  ./ (1 file)
    - archive-directions-03.pdf
  png/ (4 files)
    - direction-c-markers-1024.png
    - direction-c-markers-512.png
    - direction-c-wordmark-1024.png
    - direction-c-wordmark-512.png
  svg/ (2 files)
    - direction-c-markers.svg
    - direction-c-wordmark.svg

Palette
  #0D0E11  #BE8B32  #EFEBE2

SVG is the master. PNG is rasterised at the standard sizes.
